package calculadora;

public class Calculator {

	public Calculator () {
	
	}
	/**
	 * Programa de las canicas
	 */
	public void estadoSistema() {
		
		int clicks = 1;
		
		System.out.println("El estado del sistema en " + clicks + " clicks de tiempo es: ");
		
		Complex num1 = new Complex(0,0);
		Complex num2 = new Complex(0,0);
		Complex num3 = new Complex(0,0);
		Complex num4 = new Complex(0,0);
		Complex num5 = new Complex(0,0);
		Complex num6 = new Complex(0,0);
		Complex num7 = new Complex(0,0);
		Complex num8 = new Complex(1,0);
		Complex num9 = new Complex(0,0);
		Complex num10 = new Complex(1,0);
		Complex num11 = new Complex(1,0);
		Complex num12 = new Complex(0,0);
		Complex num13 = new Complex(1,0);
		Complex num14 = new Complex(0,0);
		Complex num15 = new Complex(0,0);
		Complex num16 = new Complex(0,0);
		
		
		Complex[][] matrizAux = new Complex[][] {{num1,num2,num3,num4},{num5,num6,num7,num8},{num9,num10,num11,num12},{num13,num14,num15,num16}};
		ComplexArray matriz1 = new ComplexArray(matrizAux);
		
		Complex num1d = new Complex(0,0);
		Complex num2d = new Complex(0,0);
		Complex num3d = new Complex(0,0);
		Complex num4d = new Complex(1,0);
		
		Complex[][] vectorAux = new Complex[][] {{num1d},{num2d},{num3d},{num4d}};
		ComplexArray vector = new ComplexArray(vectorAux);
		
		for(int i = 0; i < clicks; i++) {
			vector = matriz1.arrayMultiplicacion(vector);
		}
		
		if (vector != null) { vector.printArray();}
		
		Complex[][] array = vector.getArray();
		double[] lista = new double[array.length];
		for (int i = 0; i < array.length; i++) {
			lista[i] = array[i][0].moduloCuadrado();
		}
		
		Grafica grafica = new Grafica(lista);
		grafica.setVisible();
	}
	
	public void rendijas() {
		
		int clicks = 1;
		
		System.out.println("la probabilidad en " + clicks + " clicks de tiempo es: ");
		
		Complex num1 = new Complex(0,0);
		Complex num2 = new Complex(0.2,0);
		Complex num3 = new Complex(0.3,0);
		Complex num4 = new Complex(0.5,0);
		Complex num5 = new Complex(0.3,0);
		Complex num6 = new Complex(0.2,0);
		Complex num7 = new Complex(0.1,0);
		Complex num8 = new Complex(0.4,0);
		Complex num9 = new Complex(0.4,0);
		Complex num10 = new Complex(0.3,0);
		Complex num11 = new Complex(0.2,0);
		Complex num12 = new Complex(0.1,0);
		Complex num13 = new Complex(0.3,0);
		Complex num14 = new Complex(0.3,0);
		Complex num15 = new Complex(0.4,0);
		Complex num16 = new Complex(0,0);
		
		Complex[][] matrizAux = new Complex[][] {{num1,num2,num3,num4},{num5,num6,num7,num8},{num9,num10,num11,num12},{num13,num14,num15,num16}};
		ComplexArray matriz1 = new ComplexArray(matrizAux);
		
		Complex num1d = new Complex(1,0);
		Complex num2d = new Complex(0,0);
		Complex num3d = new Complex(0,0);
		Complex num4d = new Complex(0,0);
		
		Complex[][] vectorAux = new Complex[][] {{num1d},{num2d},{num3d},{num4d}};
		ComplexArray vector = new ComplexArray(vectorAux);
		
		for(int i = 0; i < clicks; i++) {
			vector = matriz1.arrayMultiplicacion(vector);
		}
		
		if (vector != null) { vector.printArray();}
		
		Complex[][] array = vector.getArray();
		double[] lista = new double[array.length];
		for (int i = 0; i < array.length; i++) {
			lista[i] = array[i][0].moduloCuadrado();
		}
		
		Grafica grafica = new Grafica(lista);
		grafica.setVisible();
		
	}
	
	public void ensamblarSistema() {
		
		int clicks = 5;
		
		System.out.println("el sistema es: ");
		
		//matriz Matriz de la din�mica para el sistema probabil�stico A
		
		Complex num1 = new Complex(0,0);
		Complex num2 = new Complex(0.2,0);
		Complex num3 = new Complex(0.3,0);
		Complex num4 = new Complex(0.5,0);
		Complex num5 = new Complex(0.3,0);
		Complex num6 = new Complex(0.2,0);
		Complex num7 = new Complex(0.1,0);
		Complex num8 = new Complex(0.4,0);
		Complex num9 = new Complex(0.4,0);
		Complex num10 = new Complex(0.3,0);
		Complex num11 = new Complex(0.2,0);
		Complex num12 = new Complex(0.1,0);
		Complex num13 = new Complex(0.3,0);
		Complex num14 = new Complex(0.3,0);
		Complex num15 = new Complex(0.4,0);
		Complex num16 = new Complex(0,0);

		Complex[][] matriz1 = new Complex[][] {{num1,num2,num3,num4},{num5,num6,num7,num8},{num9,num10,num11,num12},{num13,num14,num15,num16}};
		ComplexArray ma = new ComplexArray(matriz1);
		
		//Matriz de la din�mica para el sistema probabil�stico B
		
		Complex num1d = new Complex(0,0);
		Complex num2d = new Complex(0.16666666,0);
		Complex num3d = new Complex(0.83333333,0);
		Complex num4d = new Complex(0.33333333,0);
		Complex num5d = new Complex(0.5,0);
		Complex num6d = new Complex(0.16666666,0);
		Complex num7d = new Complex(0.66666666,0);
		Complex num8d = new Complex(0.33333333,0);
		Complex num9d = new Complex(0,0);
		
		Complex[][] matriz2 = new Complex[][] {{num1d,num2d,num3d},{num4d,num5d,num6d},{num7d,num8d,num9d}};
		ComplexArray mb = new ComplexArray(matriz2);;
		ComplexArray tensor1 = ma.productoTensorial2(mb);
		
		Complex num1e = new Complex(0.2,0);
		Complex num2e = new Complex(0.1,0);
		Complex num3e = new Complex(0.6,0);
		Complex num4e = new Complex(0.1,0);
		
		Complex[][] matriz3 = new Complex[][] {{num1e},{num2e},{num3e},{num4e}};
		ComplexArray va = new ComplexArray(matriz3);
		
		Complex num1f = new Complex(0.7,0);
		Complex num2f = new Complex(0.15,0);
		Complex num3f = new Complex(0.15,0);
		
		Complex[][] matriz4 = new Complex[][] {{num1f},{num2f},{num3f}};
		ComplexArray vb = new ComplexArray(matriz4);
		
		ComplexArray tensor2 = va.productoTensorial2(vb);
		
		ComplexArray vector = new ComplexArray(tensor2.getArray());
		
		for(int i = 0; i < clicks; i++) {
			vector = tensor1.arrayMultiplicacion(vector);
		}
		
		if (vector != null) { vector.printArray();}
		
		Complex[][] array = vector.getArray();
		
		double[] lista2 = new double[array.length];
		for (int i = 0; i < array.length; i++) {
			lista2[i] = array[i][0].moduloCuadrado()+ 0.0025;
		}
		
		Grafica grafica = new Grafica(lista2);
		grafica.setVisible();
		
	}
	
	public static void main(String[] args) {
		Calculator calculo2 = new Calculator();
		calculo2.estadoSistema();
		calculo2.rendijas();
		calculo2.ensamblarSistema();
	}
}